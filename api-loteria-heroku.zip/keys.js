module.exports = {
    mogoUrl:"mongodb+srv://loteria:loteria@cluster0.px7e0.mongodb.net/<dbname>?retryWrites=true&w=majority",
    jwtkey:"dasdsad"
}